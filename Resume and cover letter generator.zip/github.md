repo: OlisettyVivek/Apply-app
branch: main

## Last sync
date: 2026-08-30T00:00:00Z
note: One-way — the project was authored here, not imported. Files must be pushed to the repo manually; this connection is read-only.

### Updated in this project
- Apply — iOS mobile app prototype (Design Component, Organic design system, dark theme)
- Screens: onboarding, home, resume upload + parse, paste job, writing, documents with three resume designs, auto-apply (Handshake + custom sites), applications tracker, background
- Generation is a scripted mock; no live Claude calls yet

## Screen map
| Screen | Built from |
| --- | --- |
| All screens | Apply Mobile.dc.html (single Design Component) |
| Device frame | ios-frame.jsx |
| Visual tokens | _ds/organic-98ac1cf6-5930-4bc7-85f4-24350131523b/styles.css |
